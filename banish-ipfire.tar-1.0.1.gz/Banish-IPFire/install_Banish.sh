#!/bin/bash
#
# Banish 1.4.7 for IPCop 1.4.18+
# Version 1.4.7
# Banish installation script
#
# SID Solutions
# http://sidsolutions.net
# Copyright (c) 2005/07/10 Sid McLaurin 
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
# $Id: install_Banish.sh,v 1.4.7 2008/03/18 22:13 Sid McLaurin
#
# Ported to IPFire by  Rob Brewer  [granturav8@gmail.com]  5/1/2019
#
# Set Version Number
VERSION="1.0.1"

# Start Installation
echo -e "\033[1;32mStarting Banish-IPFire 1.0.1 installation \033[0m"
/usr/bin/logger -t "banish" "Starting banish-ipfire-1.0.1 Installation"
echo

# Check if files extracted to /tmp:
echo -e "Checking if files extracted to /tmp.\c"
if [ ! -d /tmp/Banish-IPFire ] ; 
	then
    	echo
    	echo
    	echo -e "\033[1;31mError!"
    	echo
    	echo "The files are not extracted to /tmp"
    	echo -e "Please extract banish-ipire-1.0.1tar.gz in /tmp!!\033[0m"
    	/usr/bin/logger -t "banish" "Banish not extracted to /tmp, Banish installation aborted"
    	echo
     	exit 1
	else
		echo -e "...OK!"
fi
 

# Check if installation files exits
echo -e "Checking files......................\c"
if [ ! -f md5-check -o \
	  ! -f install_Banish.sh -o \
	  ! -f files.tar.gz ]
	then
		echo -e	"\033[1;31mError!"
	 	echo
	 	echo "One of the following files are missing"
	 	echo "md5-check"
	 	echo "install_Banish.sh"
	 	echo "files.tar.gz"
	 	echo
	 	echo -e "Please download file again. \033[0m"
	 	/usr/bin/logger -t "banish" "Banish file check failed, Banish installation aborted"
	 	echo
	 	exit 1
	 else
		echo "...OK!"
fi	 

# Perform MD5SUM Check
#echo -e "Checking md5sum.....................\c"

# Run check and capture output
md5sum -c md5-check >test 2>&1
WARNING=`cat test|grep FAILED`

if [ "$WARNING" ]
	 then
	 echo -e "\033[1;31mError!"
	 echo
	 echo -e "WARNING! MD5-check failed, installation aborted."
	 echo -e "Please download installation file again. \033[0m"
	 /usr/bin/logger -t "banish" "MD5-check failed, Banish installation aborted"
	 echo
	 exit 1
	else
	 echo "...OK!"
fi

# Check for previous versions
if [ -x /usr/local/bin/uninstall_Banish.sh ]
   then
	echo
	echo -e "\033[1;33mPrevious installation detected \033[0m"
	
	# Backup Banish configuration files
	if [ -e /var/ipfire/Banish/Banish_config ]
		then
		
		# Get current installed Banish Version
		BANVERSION=`cat /usr/local/bin/uninstall_Banish.sh|grep Version|awk ' { print $3 } '`
		
		# See if this will be an upgrade
		UPGRADE=`echo $VERSION $BANVERSION|awk '{ print ($1 > $2) ? "true" : "false" }'`
   		
		if [ "$UPGRADE" = "true" ]
			then
				echo
				echo -e "\033[1;33mUninstalling first \033[0m"
				cp -p /var/ipfire/Banish/Banish_config .
				cp -p /var/ipfire/Banish/ip_Banishlist .
				if [ -e /var/ipfire/Banish/Banish_settings ]
					then
						cp -p /var/ipfire/Banish/Banish_settings .
				fi
				/usr/local/bin/uninstall_Banish.sh
				echo -e "\033[1;33mContinuing with install \033[0m"
			else
				echo
				echo -e "\033[1;33mYou have the current version of banish Banish installed"
				echo -e "To reinstall, run /usr/local/bin/uninstall_Banish.sh first"
				/usr/bin/logger -t "banish" "Current version of banish Banish already installed"
				echo -e "Exiting installation \033[0m"
				echo
				exit 1
		fi
	fi			
fi


# Backup files
echo -e "Backing up files.....................\c"

if [ ! -d /Banish ]
	then
	/bin/mkdir /Banish >/dev/null 2>&1
fi

	
/bin/cp -p /var/ipfire/langs/en.pl /Banish/en.pl.bak
/bin/cp -p /srv/web/ipfire/cgi-bin/ipinfo.cgi /Banish/ipinfo.cgi.bak
/bin/cp -p /srv/web/ipfire/cgi-bin/logs.cgi/firewalllog.dat /Banish/firewalllog.dat.bak
/bin/cp -p /srv/web/ipfire/cgi-bin/logs.cgi/log.dat /Banish/log.dat.bak
/bin/cp -p /etc/sudoers /Banish/sudoers.bak
echo "Done!"

# Extract files
echo -e "Extracting files.....................\c"
tar xzf files.tar.gz
echo "Done!"

# Install Banish files
echo -e "Installing system files..............\c"

# Make Banish image directory
/bin/mkdir /srv/web/ipfire/html/images/Banish >/dev/null 2>&1

# Install System files
/bin/cp -p Banish/usr/local/bin/* /usr/local/bin/

/bin/cp -p Banish/srv/web/ipfire/cgi-bin/BanishGeo.cgi /srv/web/ipfire/cgi-bin/BanishGeo.cgi
/bin/cp -p Banish/srv/web/ipfire/cgi-bin/logs.cgi/Banishlog.dat /srv/web/ipfire/cgi-bin/logs.cgi/Banishlog.dat
/bin/cp -p Banish/srv/web/ipfire/html/images/* /srv/web/ipfire/html/images/Banish/
/bin/cp -p Banish/etc/rc.d/init.d/rc.banish /etc/rc.d/init.d/

# add links for sysv
ln -s /etc/rc.d/init.d/rc.banish /etc/rc.d/rc0.d/K75banish
ln -s /etc/rc.d/init.d/rc.banish /etc/rc.d/rc3.d/S50banish
ln -s /etc/rc.d/init.d/rc.banish /etc/rc.d/rc6.d/K75banish

# Use previous configuration files if they exist
if [ -s Banish_config ]
   	then
   		/bin/mkdir /var/ipfire/Banish
		/bin/cp -p Banish_config /var/ipfire/Banish/
		/bin/cp -p ip_Banishlist /var/ipfire/Banish/
		/bin/cp -p Banish/var/ipfire/Banish/Banish-functions.pl /var/ipfire/Banish/
		if [ -s /var/ipfire/Banish/rm_Banishlist ]
			then
				/bin/cp -p ip_Banishlist /var/ipfire/Banish/rm_Banishlist
   		else
   			/bin/cp -p Banish/var/ipfire/Banish/rm_Banishlist /var/ipfire/Banish/
		fi
		if [ -s Banish_settings ]
			then
				/bin/cp -p Banish_settings /var/ipfire/Banish/
		else
			/bin/cp -p Banish/var/ipfire/Banish/Banish_settings /var/ipfire/Banish/
		fi
   	else
		# Make Banish directory and install files
		/bin/mkdir /var/ipfire/Banish
		/bin/cp -rp Banish/var/ipfire/Banish/* /var/ipfire/Banish/
fi

echo "Done!"

# Appending files
echo -e "Appending to files...................\c"

# Add menu items
/bin/cp -p Banish/EX-banish.menu /var/ipfire/menu.d/EX-banish.menu
/bin/cp -p Banish/EX-Banishlog.menu /var/ipfire/menu.d/EX-Banishlog.menu

# Add Languages
# English
/bin/cp Banish/Banish.en.pl /var/ipfire/addon-lang/Banish.en.pl

# Deutsch
/bin/cp Banish/Banish.de.pl /var/ipfire/addon-lang/Banish.de.pl

# French
/bin/cp Banish/Banish.fr.pl /var/ipfire/addon-lang/Banish.fr.pl

# Italian
/bin/cp Banish/Banish.it.pl /var/ipfire/addon-lang/Banish.it.pl

# Spanish
/bin/cp Banish/Banish.es.pl /var/ipfire/addon-lang/Banish.es.pl

# Portuguese
/bin/cp Banish/Banish.pt.pl /var/ipfire/addon-lang/Banish.pt.pl

# Netherlands
/bin/cp Banish/Banish.nl.pl /var/ipfire/addon-lang/Banish.nl.pl

# Lang Script Cache Compliation 
perl -e "require '/var/ipfire/lang.pl'; &Lang::BuildCacheLang"

# Add network "whois" lookups
/bin/cat /srv/web/ipfire/cgi-bin/ipinfo.cgi |sed -e '/my.$whoisname/ r Banish/Banish_ipinfo.pl'>ipinfo.cgi.tmp
/usr/bin/perl -pi.old -e "s/addr \./address \./g" ipinfo.cgi.tmp 
/bin/cp ipinfo.cgi.tmp /srv/web/ipfire/cgi-bin/ipinfo.cgi

# Add firewall log tweak
/bin/cat /srv/web/ipfire/cgi-bin/logs.cgi/firewalllog.dat |sed -e '/my.$chain/ r Banish/Banish_firewalllog.pl'>firewalllog.dat.tmp
/bin/cp firewalllog.dat.tmp /srv/web/ipfire/cgi-bin/logs.cgi/firewalllog.dat

# Add system log tweak
/bin/cat /srv/web/ipfire/cgi-bin/logs.cgi/log.dat |sed -e '/pluto/ r Banish/Banish_log.pl'>log.dat.tmp
/bin/cat log.dat.tmp |sed -e '/IPSec/ r Banish/Banish_log2.pl'>log.dat.tmp2
/bin/cp log.dat.tmp2 /srv/web/ipfire/cgi-bin/logs.cgi/log.dat
echo "Done!"

# Add  banish to sudoers
/bin/cat Banish/Banish_sudo.sh >>/etc/sudoers



# Run Banish
echo -e "Starting Banish......................\c"
/etc/rc.d/init.d/banish start
echo "Done!"  

# Cleaning up
echo -e "Cleaning up..........................\c"
/bin/rm -rf *
cd ..
/bin/rm -rf /tmp/Banish-IPFire

echo -e  "Done!\n"

echo -e "\033[1;32mBanish Installation Complete \033[0m"
/usr/bin/logger -t "banish" "Banish-IPFire-1.0.1 Installation Completed"
